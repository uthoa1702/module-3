CREATE VIEW USER_ATTRIBUTES AS
SELECT `mysql`.`user`.`User`                                                      AS `USER`,
       `mysql`.`user`.`Host`                                                      AS `HOST`,
       JSON_UNQUOTE(JSON_EXTRACT(`mysql`.`user`.`User_attributes`, '$.metadata')) AS `ATTRIBUTE`
FROM `mysql`.`user`
WHERE (0 <> can_access_user(`mysql`.`user`.`User`, `mysql`.`user`.`Host`));

