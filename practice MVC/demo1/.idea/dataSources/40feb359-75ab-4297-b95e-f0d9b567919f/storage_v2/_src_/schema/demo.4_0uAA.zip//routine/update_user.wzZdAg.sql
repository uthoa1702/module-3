CREATE
    DEFINER = root@localhost PROCEDURE update_user(IN p_id INT, IN p_name VARCHAR(120), IN p_email VARCHAR(220),
                                                   IN p_country VARCHAR(120))
BEGIN
        update users SET name = p_name, email = p_email, country = p_country  WHERE id = p_id;
    END;

