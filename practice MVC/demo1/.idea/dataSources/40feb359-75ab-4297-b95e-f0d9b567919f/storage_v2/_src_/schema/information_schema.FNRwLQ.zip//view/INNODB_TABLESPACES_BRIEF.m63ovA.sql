CREATE VIEW INNODB_TABLESPACES_BRIEF AS
SELECT get_dd_tablespace_private_data(`ts`.`se_private_data`, 'id')    AS `SPACE`,
       `ts`.`name`                                                     AS `NAME`,
       `ts_files`.`file_name`                                          AS `PATH`,
       get_dd_tablespace_private_data(`ts`.`se_private_data`, 'flags') AS `FLAG`,
       IF((get_dd_tablespace_private_data(`ts`.`se_private_data`, 'id') = 0), 'System',
          IF((((get_dd_tablespace_private_data(`ts`.`se_private_data`, 'flags') & 2048) >> 11) <> 0), 'General',
             'Single'))                                                AS `SPACE_TYPE`
FROM (`mysql`.`tablespace_files` `ts_files` JOIN `mysql`.`tablespaces` `ts`
      ON ((`ts`.`id` = `ts_files`.`tablespace_id`)))
WHERE ((`ts`.`se_private_data` IS NOT NULL) AND (`ts`.`engine` = 'InnoDB') AND (`ts`.`name` <> 'mysql') AND
       (`ts`.`name` <> 'innodb_temporary'));

