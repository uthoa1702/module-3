CREATE
    DEFINER = root@localhost PROCEDURE delete_order(IN o_id INT)
UPDATE `order`
SET
    status = 1
WHERE id = o_id;

