CREATE VIEW VIEWS AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci)                                         AS `TABLE_CATALOG`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci)                                         AS `TABLE_SCHEMA`,
       (`vw`.`name` COLLATE utf8mb3_tolower_ci)                                          AS `TABLE_NAME`,
       IF((can_access_view(`sch`.`name`, `vw`.`name`, `vw`.`view_definer`, `vw`.`options`) = TRUE),
          `vw`.`view_definition_utf8`, '')                                               AS `VIEW_DEFINITION`,
       `vw`.`view_check_option`                                                          AS `CHECK_OPTION`,
       `vw`.`view_is_updatable`                                                          AS `IS_UPDATABLE`,
       `vw`.`view_definer`                                                               AS `DEFINER`,
       IF((`vw`.`view_security_type` = 'DEFAULT'), 'DEFINER', `vw`.`view_security_type`) AS `SECURITY_TYPE`,
       `cs`.`name`                                                                       AS `CHARACTER_SET_CLIENT`,
       `conn_coll`.`name`                                                                AS `COLLATION_CONNECTION`
FROM (((((`mysql`.`tables` `vw` JOIN `mysql`.`schemata` `sch`
          ON ((`vw`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
         ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN `mysql`.`collations` `conn_coll`
        ON ((`conn_coll`.`id` = `vw`.`view_connection_collation_id`))) JOIN `mysql`.`collations` `client_coll`
       ON ((`client_coll`.`id` = `vw`.`view_client_collation_id`))) JOIN `mysql`.`character_sets` `cs`
      ON ((`cs`.`id` = `client_coll`.`character_set_id`)))
WHERE ((0 <> can_access_table(`sch`.`name`, `vw`.`name`)) AND (`vw`.`type` = 'VIEW'));

