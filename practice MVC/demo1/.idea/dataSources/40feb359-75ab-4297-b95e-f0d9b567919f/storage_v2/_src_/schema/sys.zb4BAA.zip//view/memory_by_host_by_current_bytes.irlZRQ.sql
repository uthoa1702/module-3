CREATE DEFINER = `mysql.sys`@localhost VIEW memory_by_host_by_current_bytes AS
SELECT IF((`performance_schema`.`memory_summary_by_host_by_event_name`.`HOST` IS NULL), 'background',
          `performance_schema`.`memory_summary_by_host_by_event_name`.`HOST`)                                        AS `host`,
       SUM(`performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_COUNT_USED`)                         AS `current_count_used`,
       format_bytes(SUM(`performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`)) AS `current_allocated`,
       format_bytes(IFNULL(
               (SUM(`performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`) /
                NULLIF(SUM(`performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_COUNT_USED`), 0)),
               0))                                                                                                   AS `current_avg_alloc`,
       format_bytes(MAX(`performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`)) AS `current_max_alloc`,
       format_bytes(SUM(`performance_schema`.`memory_summary_by_host_by_event_name`.`SUM_NUMBER_OF_BYTES_ALLOC`))    AS `total_allocated`
FROM `performance_schema`.`memory_summary_by_host_by_event_name`
GROUP BY IF((`performance_schema`.`memory_summary_by_host_by_event_name`.`HOST` IS NULL), 'background',
            `performance_schema`.`memory_summary_by_host_by_event_name`.`HOST`)
ORDER BY SUM(`performance_schema`.`memory_summary_by_host_by_event_name`.`CURRENT_NUMBER_OF_BYTES_USED`) DESC;

