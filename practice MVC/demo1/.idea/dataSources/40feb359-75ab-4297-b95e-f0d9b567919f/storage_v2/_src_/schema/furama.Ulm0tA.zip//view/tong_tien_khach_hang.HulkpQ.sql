CREATE DEFINER = root@localhost VIEW tong_tien_khach_hang AS
SELECT `kh`.`ma_khach_hang`                                                                  AS `ma_khach_hang`,
       `kh`.`ho_ten`                                                                         AS `ho_ten`,
       `lk`.`ten_loai_khach`                                                                 AS `ten_loai_khach`,
       `hd`.`ma_hop_dong`                                                                    AS `ma_hop_dong`,
       `dv`.`ten_dich_vu`                                                                    AS `ten_dich_vu`,
       `hd`.`ngay_lam_hop_dong`                                                              AS `ngay_lam_hop_dong`,
       `hd`.`ngay_ket_thuc`                                                                  AS `ngay_ket_thuc`,
       IFNULL((`dv`.`chi_phi_thue` + IFNULL(SUM((`hdct`.`so_luong` * `dvdk`.`gia`)), 0)), 0) AS `tong_tien`
FROM (((((`furama`.`khach_hang` `kh` JOIN `furama`.`loai_khach` `lk`
          ON ((`lk`.`ma_loai_khach` = `kh`.`ma_loai_khach`))) LEFT JOIN `furama`.`hop_dong` `hd`
         ON ((`hd`.`ma_khach_hang` = `kh`.`ma_khach_hang`))) LEFT JOIN `furama`.`hop_dong_chi_tiet` `hdct`
        ON ((`hdct`.`ma_hop_dong` = `hd`.`ma_hop_dong`))) LEFT JOIN `furama`.`dich_vu_di_kem` `dvdk`
       ON ((`dvdk`.`ma_dich_vu_di_kem` = `hdct`.`ma_dich_vu_di_kem`))) LEFT JOIN `furama`.`dich_vu` `dv`
      ON ((`dv`.`ma_dich_vu` = `hd`.`ma_dich_vu`)))
GROUP BY `kh`.`ma_khach_hang`, `hd`.`ma_hop_dong`
ORDER BY `kh`.`ma_khach_hang`, `tong_tien` DESC;

