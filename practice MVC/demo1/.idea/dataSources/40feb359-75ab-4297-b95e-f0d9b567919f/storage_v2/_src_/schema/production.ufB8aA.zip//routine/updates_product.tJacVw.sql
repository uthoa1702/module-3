CREATE
    DEFINER = root@localhost PROCEDURE updates_product(IN p_id INT, IN p_product_code VARCHAR(5),
                                                       IN p_product_name VARCHAR(50), IN p_product_price DOUBLE,
                                                       IN p_product_amount INT, IN p_product_description VARCHAR(50),
                                                       IN p_product_status BIT)
BEGIN 
 UPDATE products 
 SET
 id = p_id,
  product_code = p_product_code,
  product_name = p_product_name,
  product_price = p_product_price,
  product_amount = p_product_amount,
  product_description = p_product_description,
  product_status = p_product_status
WHERE
id = p_id;
END;

