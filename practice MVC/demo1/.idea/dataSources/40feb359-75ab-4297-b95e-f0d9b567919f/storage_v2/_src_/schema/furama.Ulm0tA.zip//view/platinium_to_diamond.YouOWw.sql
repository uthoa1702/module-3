CREATE DEFINER = root@localhost VIEW platinium_to_diamond AS
SELECT `furama`.`tong_tien_khach_hang`.`ma_khach_hang`     AS `ma_khach_hang`,
       SUM(`furama`.`tong_tien_khach_hang`.`tong_tien`)    AS `sum(tong_tien)`,
       `furama`.`tong_tien_khach_hang`.`ten_loai_khach`    AS `ten_loai_khach`,
       `furama`.`tong_tien_khach_hang`.`ngay_lam_hop_dong` AS `ngay_lam_hop_dong`
FROM `furama`.`tong_tien_khach_hang`
WHERE ((YEAR(`furama`.`tong_tien_khach_hang`.`ngay_lam_hop_dong`) = 2021) AND
       (`furama`.`tong_tien_khach_hang`.`ten_loai_khach` LIKE 'Platinium') AND
       (`furama`.`tong_tien_khach_hang`.`tong_tien` > 1000000))
GROUP BY `furama`.`tong_tien_khach_hang`.`ma_khach_hang`, `furama`.`tong_tien_khach_hang`.`ma_hop_dong`;

