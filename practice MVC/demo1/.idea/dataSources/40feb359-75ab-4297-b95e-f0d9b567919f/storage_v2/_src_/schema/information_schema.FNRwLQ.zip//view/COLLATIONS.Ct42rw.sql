CREATE VIEW COLLATIONS AS
SELECT `col`.`name`                                                                                AS `COLLATION_NAME`,
       `cs`.`name`                                                                                 AS `CHARACTER_SET_NAME`,
       `col`.`id`                                                                                  AS `ID`,
       IF(EXISTS(SELECT 1
                 FROM `mysql`.`character_sets`
                 WHERE (`mysql`.`character_sets`.`default_collation_id` = `col`.`id`)), 'Yes', '') AS `IS_DEFAULT`,
       IF(`col`.`is_compiled`, 'Yes', '')                                                          AS `IS_COMPILED`,
       `col`.`sort_length`                                                                         AS `SORTLEN`,
       `col`.`pad_attribute`                                                                       AS `PAD_ATTRIBUTE`
FROM (`mysql`.`collations` `col` JOIN `mysql`.`character_sets` `cs` ON ((`col`.`character_set_id` = `cs`.`id`)));

