CREATE
    DEFINER = root@localhost PROCEDURE delete_customer(IN c_id INT, IN a_id INT)
BEGIN
    DELETE  FROM customer AS c
    WHERE c.id=c_id;
    DELETE FROM `account`AS a
    WHERE a.account_id=a_id;
END;

