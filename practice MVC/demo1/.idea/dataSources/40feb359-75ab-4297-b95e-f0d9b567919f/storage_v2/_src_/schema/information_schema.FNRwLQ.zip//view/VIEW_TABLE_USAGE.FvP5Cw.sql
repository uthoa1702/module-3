CREATE VIEW VIEW_TABLE_USAGE AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci)          AS `VIEW_CATALOG`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci)          AS `VIEW_SCHEMA`,
       (`vw`.`name` COLLATE utf8mb3_tolower_ci)           AS `VIEW_NAME`,
       (`vtu`.`table_catalog` COLLATE utf8mb3_tolower_ci) AS `TABLE_CATALOG`,
       (`vtu`.`table_schema` COLLATE utf8mb3_tolower_ci)  AS `TABLE_SCHEMA`,
       (`vtu`.`table_name` COLLATE utf8mb3_tolower_ci)    AS `TABLE_NAME`
FROM (((`mysql`.`tables` `vw` JOIN `mysql`.`schemata` `sch`
        ON ((`vw`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
       ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN `mysql`.`view_table_usage` `vtu` ON ((`vtu`.`view_id` = `vw`.`id`)))
WHERE ((0 <> can_access_table(`vtu`.`table_schema`, `vtu`.`table_name`)) AND (`vw`.`type` = 'VIEW') AND
       (0 <> can_access_view(`sch`.`name`, `vw`.`name`, `vw`.`view_definer`, `vw`.`options`)));

