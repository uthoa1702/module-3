CREATE
    DEFINER = root@localhost PROCEDURE display_all()
BEGIN
    SELECT *
    FROM users;
END;

