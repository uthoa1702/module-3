CREATE VIEW STATISTICS AS
SELECT (`cat`.`name` COLLATE utf8mb3_tolower_ci)                                                         AS `TABLE_CATALOG`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci)                                                         AS `TABLE_SCHEMA`,
       (`tbl`.`name` COLLATE utf8mb3_tolower_ci)                                                         AS `TABLE_NAME`,
       IF(((`idx`.`type` = 'PRIMARY') OR (`idx`.`type` = 'UNIQUE')), 0, 1)                               AS `NON_UNIQUE`,
       (`sch`.`name` COLLATE utf8mb3_tolower_ci)                                                         AS `INDEX_SCHEMA`,
       (`idx`.`name` COLLATE utf8mb3_tolower_ci)                                                         AS `INDEX_NAME`,
       `icu`.`ordinal_position`                                                                          AS `SEQ_IN_INDEX`,
       IF((`col`.`hidden` = 'SQL'), NULL,
          (`col`.`name` COLLATE utf8mb3_tolower_ci))                                                     AS `COLUMN_NAME`,
       (CASE WHEN (`icu`.`order` = 'DESC') THEN 'D' WHEN (`icu`.`order` = 'ASC') THEN 'A' ELSE NULL END) AS `COLLATION`,
       internal_index_column_cardinality(`sch`.`name`, `tbl`.`name`, `idx`.`name`, `col`.`name`,
                                         `idx`.`ordinal_position`, `icu`.`ordinal_position`,
                                         IF((`tbl`.`partition_type` IS NULL), `tbl`.`engine`, ''),
                                         `tbl`.`se_private_id`,
                                         ((`tbl`.`hidden` <> 'Visible') OR (0 <> `idx`.`hidden`) OR
                                          (0 <> `icu`.`hidden`)),
                                         COALESCE(`stat`.`cardinality`, CAST(-(1) AS UNSIGNED)),
                                         COALESCE(CAST(`stat`.`cached_time` AS UNSIGNED), 0))            AS `CARDINALITY`,
       get_dd_index_sub_part_length(`icu`.`length`, `col`.`type`, `col`.`char_length`, `col`.`collation_id`,
                                    `idx`.`type`)                                                        AS `SUB_PART`,
       NULL                                                                                              AS `PACKED`,
       IF((`col`.`is_nullable` = 1), 'YES', '')                                                          AS `NULLABLE`,
       (CASE
            WHEN (`idx`.`type` = 'SPATIAL') THEN 'SPATIAL'
            WHEN (`idx`.`algorithm` = 'SE_PRIVATE') THEN ''
            ELSE `idx`.`algorithm` END)                                                                  AS `INDEX_TYPE`,
       IF(((`idx`.`type` = 'PRIMARY') OR (`idx`.`type` = 'UNIQUE')), '',
          IF(internal_keys_disabled(`tbl`.`options`), 'disabled', ''))                                   AS `COMMENT`,
       `idx`.`comment`                                                                                   AS `INDEX_COMMENT`,
       IF(`idx`.`is_visible`, 'YES', 'NO')                                                               AS `IS_VISIBLE`,
       IF((`col`.`hidden` = 'SQL'), `col`.`generation_expression_utf8`, NULL)                            AS `EXPRESSION`
FROM (((((((`mysql`.`index_column_usage` `icu` JOIN `mysql`.`indexes` `idx`
            ON ((`idx`.`id` = `icu`.`index_id`))) JOIN `mysql`.`tables` `tbl`
           ON ((`idx`.`table_id` = `tbl`.`id`))) JOIN `mysql`.`columns` `col`
          ON ((`icu`.`column_id` = `col`.`id`))) JOIN `mysql`.`schemata` `sch`
         ON ((`tbl`.`schema_id` = `sch`.`id`))) JOIN `mysql`.`catalogs` `cat`
        ON ((`cat`.`id` = `sch`.`catalog_id`))) JOIN `mysql`.`collations` `coll`
       ON ((`tbl`.`collation_id` = `coll`.`id`))) LEFT JOIN `mysql`.`index_stats` `stat`
      ON (((`tbl`.`name` = `stat`.`table_name`) AND (`sch`.`name` = `stat`.`schema_name`) AND
           (`idx`.`name` = `stat`.`index_name`) AND (`col`.`name` = `stat`.`column_name`))))
WHERE ((0 <> can_access_table(`sch`.`name`, `tbl`.`name`)) AND
       (0 <> is_visible_dd_object(`tbl`.`hidden`, ((0 <> `idx`.`hidden`) OR (0 <> `icu`.`hidden`)), `idx`.`options`)));

